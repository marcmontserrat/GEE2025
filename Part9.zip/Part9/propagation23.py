############################################################################
############# This file is an execution file of the study module ###########   
############################################################################
from IPython import get_ipython
try:
    get_ipython().magic('reset -sf')
    
    print('Windows')
except:
    print('linux')

#########################
# To modify by the user #
#########################

import csv
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import pickle
import openturns as ot
from mpl_toolkits.mplot3d import Axes3D

# Load the saved metamodel for sensitivity analysis
#with open("metamodel.pkl", "rb") as f:
with open("kriging_model.pkl", "rb") as f:
    metamodel = pickle.load(f)
    #with open("kriging_model.pkl", "rb") as file:
    #loaded_model = pickle.load(file)

#with open("surrogate.pkl", "wb") as f:
    #pickle.dump(surrogate, f)
    
# Define the input distributions for sensitivity analysis
#distribution_Y = ot.InverseNormal(11.7154, 15.3498)
#distribution_Y = ot.TruncatedDistribution(distribution_Y, 0.0, 110.0)

# Define the random distribution for Monte Carlo
distribUCS = ot.InverseNormal(16.0959, 22.3806)  # 2018 without outliers
distribUCS = ot.TruncatedDistribution(distribUCS, 0.0, 110.0)

#inputs = np.column_stack((UCS, ExternalD, WallT, MPlength))
#bounds = [(2.1, 10.5), (0.0234, 0.1305), (7., 41.)] #DoE

#distribExternalD = ot.Uniform(2.1, 10.5)
#distribWallT = ot.Uniform(0.0234, 0.1305)
#distribMPlength = ot.Uniform(7.0, 41.0)

distribWallT = ot.Uniform(0.95, 1.05)

#input_names = ["MP embedded length", "UCS [MPa]"] 
#input_names = ["UCS [MPa]", "ExternalD", "WallT", "MP embedded length"] 

#distribUCS, distribExternalD, distribWallT, distribMPlength
#distribution_X = ot.Uniform(7.0, 43.0)
#distribution_X = ot.TruncatedDistribution(distribution_Y, 0.93, 1.1)

#inputs = np.column_stack((X, Y))
#input_sample = ot.Sample(inputs.tolist())
# Predict Z using the metamodel
#Z_pred = np.array([metamodel(x) for x in input_sample]).flatten()

#print(input_sample)
#print(Z_pred)

#print(type(input_sample))
#print(type(Z_pred))
#import pdb;pdb.set_trace(); 

#inputs = np.column_stack((UCS, ExternalD, WallT, MPlength))
#input_distribution = ot.ComposedDistribution([distribUCS, distribExternalD, distribWallT, distribMPlength])
input_distribution = ot.ComposedDistribution([distribWallT, distribUCS])

# Define the input sample size for the Sobol indices computation
input_sample_size = int(1e4)  # Number of samples for the Sobol indices computation

# Generate the input sample for sensitivity analysis
input_sample = input_distribution.getSample(input_sample_size)  # This is an OpenTURNS Sample

# Make sure the metamodel is called correctly on each input
# Predict Z using the metamodel
Z_pred = np.array([metamodel(x) for x in input_sample]).flatten()

# Perform Sobol sensitivity analysis using the metamodel and input distribution
sensitivity_analysis = ot.SaltelliSensitivityAlgorithm(input_distribution, input_sample_size, metamodel)

# Retrieve and display Sobol indices
first_order_indices = sensitivity_analysis.getFirstOrderIndices()
total_order_indices = sensitivity_analysis.getTotalOrderIndices()

print(f"First-order Sobol indices: {first_order_indices}")
print(f"Total-order Sobol indices: {total_order_indices}")

# Assuming first_order_indices and total_order_indices are retrieved
sum_first_order = np.sum(first_order_indices)
sum_total_order = np.sum(total_order_indices)

print(f"Sum of first-order indices: {sum_first_order}")
print(f"Sum of total-order indices: {sum_total_order}")

#import pdb;pdb.set_trace();

# Number of input variables
#num_inputs = len(first_order_indices)

## Plotting Sobol indices
#input_labels = ["X", "Y"]  # Labels for the input variables

## Create the plot
#fig, ax = plt.subplots(figsize=(10, 6))

## Bar width
#bar_width = 0.35

## Positions of the bars
#index = np.arange(num_inputs)

## Plot first-order Sobol indices
#ax.bar(index, first_order_indices, bar_width, label='First-order Sobol indices', color='b')

## Plot total-order Sobol indices
#ax.bar(index + bar_width, total_order_indices, bar_width, label='Total-order Sobol indices', color='r')

## Set labels and title
#ax.set_xlabel('Input Variables')
#ax.set_ylabel('Sobol Indices')
#ax.set_title('Sobol Indices for Input Variables')
#ax.set_xticks(index + bar_width / 2)
#ax.set_xticklabels(input_labels)
#ax.legend()

## Display the plot
#plt.show()

# Names for the input variables (adjust based on your input variables)
#input_names = ["X", "Y"]
#input_names = ["MP embedded length", "UCS [MPa]"] 
input_names = ["WallT Factor", "UCS [MPa]"] 
x = np.arange(len(input_names))

# Create the plot
plt.figure(figsize=(10, 5))

# Plot first-order indices as blue points
plt.scatter(x, first_order_indices, color='blue', label='First Order Sobol Indices')

# Plot total-order indices as red points
plt.scatter(x, total_order_indices, color='red', label='Total Order Sobol Indices')

# Set plot details
plt.xticks(x, input_names)
plt.xlabel('Input Variables')
plt.ylabel('Sobol Indices')
plt.title('Sobol Indices Plot')
plt.legend()
plt.grid(True)

# Show the plot
plt.show()

