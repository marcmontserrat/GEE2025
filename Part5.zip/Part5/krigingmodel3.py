############################################################################
############# This file is an execution file of the study module ###########   
############################################################################
from IPython import get_ipython
try:
    get_ipython().magic('reset -sf')
    
    print('Windows')
except:
    print('linux')

#########################
# To modify by the user #
#########################

import csv
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import pickle
import openturns as ot

X = [];
Y = [];
#with open('FreqOriginalDesign14.csv', mode='r') as file:
#with open('FreqBiggerDiamMP.csv', mode='r') as file:
#with open('FreqSmallDiamMP.csv', mode='r') as file:    
#with open('FreqLargerThicknessMP.csv', mode='r') as file:        
#with open('FreqSmallThicknessMP.csv', mode='r') as file: 
#with open('FreqBiggerDiamMP5.csv', mode='r') as file:
#with open('FreqSmallDiamMP5.csv', mode='r') as file:

XY = np.loadtxt('data/FreqOriginalDesign14.csv', delimiter=',')
#XY = np.loadtxt('data/DesginLengthMinus.csv', delimiter=',')
X = XY[:, 0] #UCS
#Y = XY[:, 0] #length
#Y = XY[:, 2] #diam
#Y = XY[:, 3] #thickn
Y = XY[:, 1]

# Plot the original input-output data to visualize it
plt.scatter(X, Y, label="Original Data")
plt.title("Original Input-Output Data")
plt.xlabel("Input (X)")
plt.ylabel("Output (Y)")
plt.legend()
#plt.show()
plt.savefig('figures/DOE_scatterplot.png')

indices = np.arange(len(X))
indices[::5]

test_indices = indices[4::5]
#print(test_indices)
#import pdb;pdb.set_trace();

train_indices = np.delete(indices,indices[::5])

train_input_sample = ot.Sample(X[train_indices].reshape(-1, 1))
train_output_sample = ot.Sample(Y[train_indices].reshape(-1, 1))

test_input_sample = ot.Sample(X[test_indices].reshape(-1, 1))
test_output_sample = ot.Sample(Y[test_indices].reshape(-1, 1))

# Step 3: Create the Kriging metamodel using the training data
# -----------------------------------------------------------
# We use a constant basis function for the Kriging model and a Matern covariance model.
# The Matern covariance model defines the spatial correlation between points.

# Define the constant basis function for Kriging
basis = ot.ConstantBasisFactory(1).build()

# Define the Matern covariance model (with length scale 0.5 and smoothness 1.5)
covariance_model = ot.MaternModel([0.5], 1.5)

# Set up the Kriging algorithm with the training data, basis, and covariance model
kriging_algorithm = ot.KrigingAlgorithm(train_input_sample, train_output_sample, covariance_model, basis)
kriging_algorithm.run()  # Run the algorithm to train the Kriging model

# Retrieve the Kriging metamodel from the trained algorithm
kriging_result = kriging_algorithm.getResult()
metamodel = kriging_result.getMetaModel()

#with open("metamodel_DesginLengthMinus.pkl", "wb") as f:
with open("metamodel_OriginalDesign.pkl", "wb") as f:
    pickle.dump(metamodel, f)

print("Kriging metamodel successfully created.")

# Step 4: Test the metamodel on the test set and calculate performance metrics
# ---------------------------------------------------------------------------
# Use the Kriging metamodel to predict the output values for the test set.
# We then calculate the Mean Squared Error (MSE) and R² score (coefficient of determination).

# Predict the output for the test set using the Kriging metamodel
Y_pred = np.array([metamodel(x) for x in test_input_sample])

# Get the true output values for the test set
Y_test_true = np.array([y[0] for y in test_output_sample])

# Calculate the Mean Squared Error (MSE) for the test set
mse = np.mean((Y_test_true - Y_pred.flatten())**2)

# Calculate the R² score (coefficient of determination)
#ss_tot = np.sum((Y_test_true - np.mean(Y_test_true))**2)  # Total sum of squares
#ss_res = np.sum((Y_test_true - Y_pred.flatten())**2)      # Residual sum of squares
#r2 = 1 - (ss_res / ss_tot)  # R² score calculation

## Print the MSE and R² score for the test set
#print(f"Mean Squared Error (MSE) on test set: {mse}")
#print(f"R² score on test set: {r2}")

# Calculate the Q² score (predictivity coefficient)
ss_tot_test = np.mean((Y_test_true - np.mean(Y_test_true))**2)  # Total sum of squares (based on true values in test set)
#ss_res_test = np.sum((Y_test_true - Y_pred.flatten())**2)      # Residual sum of squares (based on predictions)

# Q² score calculation
q2 = 1 - (mse / ss_tot_test)

# Print the Q² score for the test set
print(f"Predictivity Coefficient (Q²) on test set: {q2}")

# Step 5: Visualize the test set, predicted values by Kriging, and training data
# ------------------------------------------------------------------------------
# We plot the true test set outputs, the predicted outputs by Kriging, and the training data.

plt.plot(test_input_sample, Y_test_true, 'r-', label='True function (Test Set)')  # Red line for true test outputs
plt.plot(test_input_sample, Y_pred, 'b--', label='Predicted by Kriging')          # Blue dashed line for Kriging predictions

#print(test_input_sample)
#import pdb;pdb.set_trace();

#plt.scatter(test_input_sample, Y_test_true, color='blue', label='True function (Test Set)')  # Red line for true test outputs
#plt.scatter(test_input_sample, Y_pred, color='green', label='Predicted by Kriging')          # Blue dashed line for Kriging predictions
plt.scatter(train_input_sample, train_output_sample, color='red', label='Training data')  # Red dots for training data

# Add plot labels and a legend
plt.title("Test Set vs Predicted by Kriging and Training Data")
plt.xlabel("Input (X)")
plt.ylabel("Output (Y)")
plt.legend()

# Show the plot
plt.show()

#import pdb;pdb.set_trace();

#print(len(Y_test_true))
#print(len(Y_pred.flatten()))

# Q-Q plot 
# x-axis values: True test values
x = Y_test_true

# y-axis values: Predicted values (flattened)
y = Y_pred.flatten()

# Create the scatter plot
plt.scatter(x, y, color='blue', alpha=0.6, edgecolors='k')

# Add labels and title
plt.xlabel('True Values (Y_test_true)')
plt.ylabel('Predicted Values (Y_pred)')
plt.title('Scatter Plot of True vs Predicted Values')

# Add a diagonal reference line for perfect predictions
min_val = min(min(x), min(y))
max_val = max(max(x), max(y))
plt.plot([min_val, max_val], [min_val, max_val], 'r--', lw=2)  # Red dashed line

# Show the plot
plt.grid(True)
plt.show()

import pdb;pdb.set_trace();

# Q-Q plot 
# Calculate the residuals (differences between true and predicted values)
residuals = Y_test_true - Y_pred.flatten()

# Generate a Q-Q plot to compare residuals to a normal distribution
fig = plt.figure()
ax = fig.add_subplot(111)
stats.probplot(residuals, dist="norm", plot=ax)

# Add 45-degree reference line
ax.get_lines()[1].set_color('r')  # Change the color of the reference line if needed
min_val = min(residuals)
max_val = max(residuals)
ax.plot([min_val, max_val], [min_val, max_val], 'r--')  # Plotting the diagonal line

# Customize the plot (optional)
plt.title('Q-Q Plot of Residuals with 45-degree Reference Line')
plt.xlabel('Theoretical Quantiles')
plt.ylabel('Sample Quantiles')

# Show the plot
plt.show()

import pdb;pdb.set_trace();


#PROPAGATION

#MCS = 1000
#test=ot.InverseNormal(16.0959, 22.3806); #2018 without outliers
#varUCS =np.array(test.getSample(MCS)); #IIa USC [kPa]

#Generate samples from the fitted inverse Gaussian distribution
num_samples = 10000  # Number of samples you want to generate
##2018
shape = 0.7467652100243791
loc = 0.22317162624119705
scale = 21.314970925434967
samples = stats.invgauss.rvs(shape, loc, scale, size=num_samples)

#varUCS1 = [2, 4, 6, 8, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60]; #MPa

#print(samples)
input_sample2 = ot.Sample(samples.reshape(-1, 1))
#print(input_sample2)
#print([2, 4, 6, 8, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60])

#import pdb;pdb.set_trace();

F_pred = np.array([metamodel(x) for x in input_sample2])
#np.array([metamodel(x) for x in test_input_sample])
#metamodel()


#print(input_sample2)
#print(input_sample2[9, 0])
#print(np.array(input_sample2[0]))
#print(type(input_sample2[0]))

#import pdb;pdb.set_trace();

F_pred2 = [];
input_sample3 = [];
isamples=0

while isamples<num_samples:
    #with open('PropagatedSample3BiggerDiamMP5.csv','a', newline='') as f:
    with open('PropagatedSample4SmallDiamMP5.csv','a', newline='') as f:
        reader = csv.reader(f)
        if input_sample2[isamples,0]<110:
            #f.write('{};{};\n'.format(samples[isamples],metamodel(samples[isamples])));
            f.write('{};{};\n'.format(samples[isamples],F_pred[isamples]));
            #F_pred2.
            input_sample3.append(input_sample2[isamples,0]);
            F_pred2.append(F_pred[isamples]);
    isamples=isamples+1

#print(varUCS)
#print(F_pred2)

#import pdb;pdb.set_trace();


# Plot histogram of data
#plt.hist(F_pred, bins=30, density=True, alpha=0.6, color='g')
#plt.hist(np.array(F_pred2), bins=25, edgecolor='black')
plt.hist(np.array(F_pred2), bins=25, edgecolor='black', density=True)

# Add titles and labels
plt.title('Histogram of Data')
plt.xlabel('Propagated first natural Frequency of OWT')
plt.ylabel('Frequency')

plt.show()

#import pdb;pdb.set_trace();


# Generate values for the PDF based on the fitted parameters
min_value = np.min(input_sample3)
max_value = np.max(input_sample3)

#print(min_value)
#print(max_value)

#import pdb;pdb.set_trace();

#xmin, xmax = plt.xlim()
x = np.linspace(min_value, max_value, 100)
p = stats.invgauss.pdf(x, shape, loc, scale)
#(shape, loc, scale, size=num_samples)

# Plot the fitted PDF
plt.plot(x, p, 'k', linewidth=2)
title = "Fitted Inverse Gaussian: shape = %.2f, loc = %.2f, scale = %.2f" % (shape, loc, scale)
plt.title(title)

plt.show()


#import pdb;pdb.set_trace();

#import matplotlib.pyplot as plt
#import numpy as np

# Example data
#X = np.random.normal(5, 1, 100)  # X data for scatter plot
#Y = np.random.normal(3, 1, 100)  # Y data for scatter plot

#x = np.linspace(0, 10, 100)  # X data for the line plot
#p = np.sin(x)  # Line plot data

#shape, loc, scale = 2, 0, 1  # Parameters for the title

#F_pred2 = np.random.normal(3, 1, 100)  # Data for the histogram

# Create the figure and GridSpec layout
fig = plt.figure(figsize=(10, 8))
#gs = fig.add_gridspec(2, 2, width_ratios=[1, 3], height_ratios=[3, 1])
gs = fig.add_gridspec(2, 3, width_ratios=[3, 1, 1], height_ratios=[3, 1])

## First graph: Scatter plot (Top-right)
ax1 = fig.add_subplot(gs[0, 0])
ax1.scatter(X, Y, label="Original Data", color="blue")
ax1.set_title("Original Input-Output Data")
ax1.set_xlabel("Input (X)")
ax1.set_ylabel("Output (Y)")
ax1.legend()

## Second graph: Line plot (Below the first graph)
ax2 = fig.add_subplot(gs[1, 0])
ax2.plot(x, p, 'k', linewidth=2)
title = "Fitted Inverse Gaussian: shape = %.2f, loc = %.2f, scale = %.2f" % (shape, loc, scale)
ax2.set_title(title)
ax2.set_xlabel("Input (X)")
ax2.set_ylabel("Fitted Values")

# Third graph: Histogram (Left of the first graph, sharing the y-axis with the first graph)
ax3 = fig.add_subplot(gs[0, 1], sharey=ax1)  # Share the y-axis with the first graph
#ax3.hist(np.array(F_pred2), bins=25, edgecolor='black', orientation='horizontal')
ax3.hist(np.array(F_pred2), bins=25, edgecolor='black', orientation='horizontal', density=True)
ax3.set_title('Histogram of Data')
ax3.set_xlabel('Frequency')
ax3.set_ylabel('')  # No label since it's shared with the first graph

# Adjust layout for better spacing
plt.tight_layout()

# Show the plot
plt.show()


import pdb;pdb.set_trace();

# List of positive-range distributions
distributions = [
    stats.norm,         # Normal distribution (can be used but has support over all real numbers)
    stats.expon,        # Exponential distribution
    stats.gamma,        # Gamma distribution
    stats.invgauss,     # Inverse Gaussian distribution
    stats.beta,         # Beta distribution
    stats.lognorm,      # Log-normal distribution
    stats.weibull_min,  # Weibull distribution
    stats.pareto,       # Pareto distribution
    stats.chi2,         # Chi-squared distribution
    stats.genextreme,   # Generalized extreme value (Frechet)
    stats.rayleigh,     # Rayleigh distribution
    stats.burr          # Burr distribution
]

best_fit = None
best_p_value = 0

for distribution in distributions:
    params = distribution.fit(np.array(F_pred2))
    ks_stat, p_value = stats.kstest(np.array(F_pred2), distribution.name, args=params)
    
    if p_value > best_p_value:
        best_fit = distribution
        best_p_value = p_value
        best_params = params

print(f"Best fitting distribution: {best_fit.name}, with p-value = {best_p_value}")

