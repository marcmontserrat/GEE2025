############################################################################
############# This file is an execution file of the study module ###########   
############################################################################
#########################
# To modify by the user #
#########################

import csv
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import openturns as ot
import pickle

mu2018 = 16.140445859872624
lambda2018 = 22.89551473946327
distrib = ot.InverseNormal(mu2018, lambda2018)
distrib = ot.TruncatedDistribution(distrib, 0.0, 110.0)

#distrib = ot.InverseNormal(16.0959, 22.3806) #2018 without outliers
#distrib = ot.TruncatedDistribution(distrib, 0.0, 110.0)

#with open("metamodel_SmallDiamMP5.pkl", "rb") as f:
    #metamodel = pickle.load(f)

#with open("metamodel_LargerThicknessMP5.pkl", "rb") as f:
    #metamodel = pickle.load(f)
with open("metamodel_OriginalDesign.pkl", "rb") as f:
    metamodel = pickle.load(f)
#with open("metamodel_SmallThicknessMP5.pkl", "rb") as f:
    #metamodel = pickle.load(f)

MCs =  [1e5, 1e6, 1e7]

SuSs =  [1e3, 1e4, 1e5]
#for element in arr:
    #print(element)
    
#Monte Carlo
print('Monte Carlo1')
XRV = ot.RandomVector(distrib)
Y = ot.CompositeRandomVector(metamodel, XRV)
#Ysample = Y.getSample(int(1e4))
#Ysample = Y.getSample(int(1e6))
#Ysample = Y.getSample(int(1e7))

#threshold = 0.2295
#threshold = 0.2285
#threshold = 0.2288
threshold = 0.2289
#threshold = 0.229
#threshold = 0.2275
#threshold = 0.19*1.2

pfs_1 = []

#for size in MCs:
    #Ysample = Y.getSample(int(size))
    #pfs_1.append(1-Ysample.computeEmpiricalCDF([threshold], True))

pfs_1 = [0.0004899999999999904, 0.00043000000000004146, 0.00045490000000003583]

print(pfs_1)

#Monte Carlo2
print('Monte Carlo2')
event = ot.ThresholdEvent(Y, ot.Less(), threshold)
experiment = ot.MonteCarloExperiment()
pfs_2 = []
pflens_2 = []
#for size in MCs:
    #size2 = size ** 0.5
    #blocksize = int(size2)
    ##experiment = ot.MonteCarloExperiment()
    #myAlgo = ot.ProbabilitySimulationAlgorithm(event, experiment)
    #myAlgo.setMaximumOuterSampling(int(size2))
    #myAlgo.setBlockSize(blocksize)
    #myAlgo.setMaximumCoefficientOfVariation(-1.)

    #myAlgo.run()

    #result = myAlgo.getResult()
    #pfs_2.append(result.getProbabilityEstimate())
    
    #alpha = 0.05
    #pflens_2.append(result.getConfidenceLength(1.0 - alpha))

pfs_2 = [0.00048069219676333854, 0.00043100000000000034, 0.00045477985934330435]
pflens_2 = [0.00027233676940075315, 8.14029509126474e-05, 2.643545066904482e-05]

print(pfs_2)
print(pflens_2)

#import pdb;pdb.set_trace();

#FORM
#optimAlgo = ot.Cobyla() 
##optimAlgo.setMaximumCallsNumber(1000)
#optimAlgo.setMaximumAbsoluteError(1.0e-10)
#optimAlgo.setMaximumRelativeError(1.0e-10)
#optimAlgo.setMaximumResidualError(1.0e-10)
#optimAlgo.setMaximumConstraintError(1.0e-10)

#algo = ot.FORM(optimAlgo, event, distrib.getMean())
#algo.run()
#result = algo.getResult()

#print('FORM')
#print(result.getEventProbability())
#print(f"Function Evaluations Used: {optimAlgo.getMaximumCallsNumber()}")

#print("Beta = ", result.getHasoferReliabilityIndex())
#print(f"Function Evaluations Used: {optimAlgo.getMaximumCallsNumber()}")

#Subset simulation
print('Subset simulation')
#https://openturns.github.io/openturns/latest/auto_reliability_sensitivity/reliability/plot_subset_sampling.html?highlight=subset
algo = ot.SubsetSampling(event)
pfs_3 = []
pflens_3 = []

#for size in SuSs:
    #algo.setMaximumOuterSampling(int(size))
    #algo.setMaximumCoefficientOfVariation(-1.)
    #algo.setConditionalProbability(0.1)
    #algo.run()
    #result = algo.getResult()
    #pfs_3.append(result.getProbabilityEstimate())
    #pflens_3.append(result.getConfidenceLength())

pfs_3 = [0.00017700000000000024, 0.0004548999999999983, 0.0004722755260000004]
pflens_3 = [0.00020227081290967143, 0.00015431921260426106, 5.1297870879178776e-05]

print(pfs_3)
print(pflens_3)

pflens_1 = [0., 0., 0.]

#x = np.array([1, 2, 3])
x = ['sample size/10', 'sample size', 'sample size*10']

# Create plot
plt.figure(figsize=(6, 4))

# Plot first line (blue)
#plt.errorbar(x, pfs_1, yerr=np.array(pflens_1) / 2.0, fmt='-o', capsize=5, label="Basic Monte Carlo. sample = 1e6", color='b')

# Plot second line (red)
plt.errorbar(x, pfs_2, yerr=np.array(pflens_2) / 2.0, fmt='-s', capsize=5, label="Monte Carlo. sample = 1e6", color='r')

# Plot third line (green)
plt.errorbar(x, pfs_3, yerr=np.array(pflens_3) / 2.0, fmt='-^', capsize=5, label="Subset simulation. sample = 1e4", color='g')

# Plot fourth line (purple)
#plt.errorbar(x, pfs_4, yerr=np.array(pflens_4) / 2.0, fmt='-d', capsize=5, label="Set 4", color='purple')

# Labels, title, and legend
#plt.xlabel("Case Index")
plt.ylabel("Probability of Failure (pf)")
plt.title("Estimation of Probability of Failure (pf) vs. sample size")
#plt.xticks(x, [f"Case {i}" for i in x])
plt.xticks(x, [f"{i}" for i in x])
#plt.legend()
plt.legend(loc='lower right')
plt.grid(True)

plt.tight_layout()  # Adjusts layout to prevent label clipping
# Show plot
plt.show()

import pdb;pdb.set_trace();

#threshold = 0.229
#ThicknessMP10
#Ysample = Y.getSample(int(1e6))
#FP1=0.014645999999999963
#FP2=0.0005020000000000003
#FP3=int(2.700000000000001e-05)

#threshold = 0.229
#ThicknessMP5
#Ysample = Y.getSample(int(1e6))
#FP1=0.002642999999999963
#FP2=0.0005020000000000003
#FP3=0.00010500000000000015

#threshold = 0.229
#ThicknessMP5
#Ysample = Y.getSample(int(1e7))
#FP1=0.0025689999999999676
#FP2=0.0005110000000000008 # decrease threshold = 0.229
#FP3=0.00012200000000000024

#threshold = 0.2288 - NO
#ThicknessMP5
#Ysample = Y.getSample(int(1e7))
#FP1=0.002064999999999974
#FP2=0.0004040000000000003
#FP3=int(9.200000000000005e-05)

threshold = 0.2289
#ThicknessMP5
Ysample = Y.getSample(int(1e1))
FP1=0.0023029999999999657
FP2=0.0004590000000000005
FP3=0.0001070000000000001


# Example with multiple datasets
data1 = np.random.normal(FP1, (FP1*(1.-FP1)/len(Ysample)), 10**2)
data2 = np.random.normal(FP2, (FP2*(1.-FP2)/len(Ysample)), 10**2)
data3 = np.random.normal(FP3, (FP3*(1.-FP3)/len(Ysample)), 10**2)

# Create multiple box plots
#plt.boxplot([Y1S, Y2S, Y3S], labels=['Nominal MP diameter ', 'Nominal MP diameter +15%', 'Nominal MP diameter -15%'])
#plt.boxplot([data1, data2, data3], labels=['MP diameter -15%', 'Nominal MP diameter ', 'MP diameter +15%'])
plt.boxplot([data1, data2, data3], labels=['MP Thickness -5%', 'Nominal MP Thickness ', 'MP Thickness +5%'])
#plt.boxplot([data1], labels=['Nominal MP diameter '])
#plt.axhline(y=0.2321, color='red', linestyle='--', linewidth=2, label='1P Threshold')
acceptable_threshold = 5*10**-4
plt.axhline(y=acceptable_threshold, color='red', linestyle='--', label=f'Threshold: $5*10^{{-4}}$')
plt.yscale('log')
#plt.set_ylim(bottom=int(1e-05))
# Add a title and labels
plt.title("Box Plot of Multiple Datasets")
plt.ylabel("Estimated probability of failure (in Logarithmic Axis)")

# Show the plot
plt.show()




