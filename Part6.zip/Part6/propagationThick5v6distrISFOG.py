############################################################################
############# This file is an execution file of the study module ###########   
############################################################################
from IPython import get_ipython
try:
    get_ipython().magic('reset -sf')
    
    print('Windows')
except:
    print('linux')

#########################
# To modify by the user #
#########################

import csv
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import pickle

#SCRIPT 2

#params are result of fitting from previous script

import openturns as ot

#Data = [0, 0];
##Data2 = [];
#Data=np.genfromtxt('FreqOriginalDesign.csv', delimiter=',', skip_header=1)
#print(Data)

X2 = [];
Y2 = [];
with open('data/FreqOriginalDesign14.csv', mode='r') as file:
#with open('FreqBiggerDiamMP.csv', mode='r') as file:
#with open('FreqSmallDiamMP.csv', mode='r') as file:    
    csv_reader = csv.reader(file, delimiter=',')
    for row in csv_reader:
        #print(row[1])
        X2.append(float(row[0]));
        Y2.append(float(row[1]));

#print(np.max(Y2))
#import pdb;pdb.set_trace();

#print(X)
#print(np.array(X))
#print(type(X[0]))

# Plot the original input-output data to visualize it
#plt.scatter(X1, Y1, label="Original Data")
#plt.scatter(X2, Y2, label="BiggerDiamMP")
#plt.scatter(X3, Y3, label="SmallDiamMP")
#plt.title("Original Input-Output Data")
#plt.xlabel("Input (X)")
#plt.ylabel("Output (Y)")
#plt.legend()
#plt.show()


MCS = int(1e7)
#OT.InverseNormal(nu, lambda)
#distrib = ot.InverseNormal(16.0959, 22.3806) #2018 without outliers
#distrib = ot.TruncatedDistribution(distrib, 0.0, 110.0)

mu2018 = 16.140445859872624
lambda2018 = 22.89551473946327
distrib = ot.InverseNormal(mu2018, lambda2018)
distrib = ot.TruncatedDistribution(distrib, 0.0, 110.0)
UCS_sample = distrib.getSample(MCS)

#print('st dev')
#print(((16.0959 ** 3)/22.3806) ** 0.5)
#import pdb;pdb.set_trace();

#with open("metamodel_SmallThicknessMP5.pkl", "rb") as f:
    #metamodel = pickle.load(f)

#output_sample1 = np.array(metamodel(UCS_sample))

#print(output_sample1)
#import pdb;pdb.set_trace();

with open("metamodel_OriginalDesign.pkl", "rb") as f:
    metamodel = pickle.load(f)

output_sample2 = np.array(metamodel(UCS_sample))

#with open("metamodel_LargerThicknessMP5.pkl", "rb") as f:
    #metamodel = pickle.load(f)
    
#output_sample3 = np.array(metamodel(UCS_sample))

#import pdb;pdb.set_trace();

# Step 1: Generate synthetic input and output data
# -----------------------------------------------
# For demonstration purposes, we generate a synthetic dataset where the inputs (X)
# are 100 points between 0 and 1, and the outputs (Y) are a sine function with added noise.
np.random.seed(42)  # Set a random seed for reproducibility
        
# Plot histogram of data
#plt.hist(F_pred, bins=30, density=True, alpha=0.6, color='g')
#plt.hist(np.array(F_pred2), bins=25, edgecolor='black')
#plt.hist(output_sample1, bins=25, edgecolor='black', density=True)
#plt.hist(output_sample2, bins=25, edgecolor='black', density=True)
#plt.hist(output_sample3, bins=25, edgecolor='black', density=True)

## Add titles and labels
#plt.title('Histogram of Data')
#plt.xlabel('Propagated first natural Frequency of OWT')
#plt.ylabel('Frequency')

#plt.show()

##import pdb;pdb.set_trace();


## Generate values for the PDF based on the fitted parameters
##min_value = np.min(input_sample3)
##max_value = np.max(input_sample3)

##print(min_value)
##print(max_value)

##import pdb;pdb.set_trace();

##xmin, xmax = plt.xlim()
x = np.linspace(1, 110, 5000)
#shape = 0.7467652100243791
#loc = 0.22317162624119705
#scale = 21.314970925434967
#p = stats.invgauss.pdf(x, shape, loc, scale)
##(shape, loc, scale, size=num_samples)

## Plot the fitted PDF
#plt.plot(x, p, 'k', linewidth=2)
#title = "Fitted Inverse Gaussian: shape = %.2f, loc = %.2f, scale = %.2f" % (shape, loc, scale)
#plt.title(title)

#plt.show()


##import pdb;pdb.set_trace();

##import matplotlib.pyplot as plt
##import numpy as np

## Example data
##X = np.random.normal(5, 1, 100)  # X data for scatter plot
##Y = np.random.normal(3, 1, 100)  # Y data for scatter plot

##x = np.linspace(0, 10, 100)  # X data for the line plot
##p = np.sin(x)  # Line plot data

##shape, loc, scale = 2, 0, 1  # Parameters for the title

##F_pred2 = np.random.normal(3, 1, 100)  # Data for the histogram

threshold = 0.2289

#print(np.max(Y2))
#import pdb;pdb.set_trace();

# Create the figure and GridSpec layout
fig = plt.figure(figsize=(10, 8))
#gs = fig.add_gridspec(2, 2, width_ratios=[1, 3], height_ratios=[3, 1])
gs = fig.add_gridspec(2, 3, width_ratios=[3, 1, 1], height_ratios=[3, 1])

## First graph: Scatter plot (Top-right)
ax1 = fig.add_subplot(gs[0, 0])
#ax1.scatter(X1, Y1, label="Original Data", color="blue")
#ax1.scatter(X2, Y2, label="Original Data", color="blue")
#ax1.scatter(X3, Y3, label="Original Data", color="blue")
#result1 = [y / threshold for y in Y1]
#result2 = [y / threshold for y in Y2]
#result3 = [y / threshold for y in Y3]
#ax1.scatter(X1, result1, label="Nominal MP Thickness -5%", marker='.')
#ax1.scatter(X2, result2, label="Nominal MP Thickness", marker='.')
#ax1.scatter(X3, result3, label="Nominal MP Thickness +5%", marker='.')
#ax1.plot(X1, Y1, label="Nominal MP diameter -5%", marker='.')
#ax1.plot(X2, Y2, label="Nominal MP diameter", marker='.')
ax1.plot(X2, Y2, marker='.')
#ax1.plot(X3, Y3, label="Nominal MP diameter +5%", marker='.')
#ax1.set_ylim(bottom=0.215/threshold)
ax1.set_ylim(bottom=0.215)
ax1.set_ylim(top=0.242)
#ax1.set_title("Original Input-Output Data")
#ax1.set_xlabel("Input (UCS, in MPa)")
#ax1.set_ylabel("First natural Frequency of OWT divided by the 1P (rotor frequency) threshold (in Hz/Hz)")
#ax1.set_ylabel("First natural Frequency of OWT divided by the 1P threshold (in Hz/Hz)")
ax1.set_ylabel("First natural Frequency of OWT (in Hz)")
#ax1.legend()

## Second graph: Line plot (Below the first graph)
#ax2 = fig.add_subplot(gs[1, 0])
#ax2.plot(x, p, 'k', linewidth=2)
#title = "Fitted Inverse Gaussian: shape = %.2f, loc = %.2f, scale = %.2f" % (shape, loc, scale)
#ax2.set_title(title)
#ax2.set_xlabel("UCS (in MPa)")
#ax2.set_ylabel("PDF (Probability Density Function)")

## Second graph: Line plot (Below the first graph)

#2018
#mu2018 = 16.140445859872624
#lambda2018 = 22.89551473946327
#distrib = ot.InverseNormal(mu2018, lambda2018)
#distrib = ot.TruncatedDistribution(distrib, 0.0, 110.0)

#pdf_values = [distrib.computePDF([i])[0] for i in x_values]
pdf_values2018 = [distrib.computePDF([i]) for i in x]
ax2 = fig.add_subplot(gs[1, 0])
ax2.plot(x, pdf_values2018, 'k', linewidth=2)
title = "Fitted Inverse Gaussian" #% (shape, loc, scale)
ax2.set_title(title)
ax2.set_xlabel("Unconfined Compressive Strength (UCS, in MPa)")
ax2.set_ylabel("PDF (Probability Density Function)")

# Third graph: Histogram (Left of the first graph, sharing the y-axis with the first graph)
ax3 = fig.add_subplot(gs[0, 1], sharey=ax1)  # Share the y-axis with the first graph
#ax3.hist(np.array(F_pred2), bins=25, edgecolor='black', orientation='horizontal')
#ax3.hist(output_sample1, bins=25, edgecolor='black', orientation='horizontal', density=True)
#ax3.hist(output_sample2, bins=25, edgecolor='black', orientation='horizontal', density=True)
#ax3.hist(output_sample3, bins=25, edgecolor='black', orientation='horizontal', density=True)
#ax3.hist(output_sample1/threshold, bins=25, edgecolor='black', orientation='horizontal')
#ax3.hist(output_sample1/threshold, bins=50, edgecolor='black', orientation='horizontal')
#ax3.hist(output_sample2/threshold, bins=50, edgecolor='black', orientation='horizontal')
ax3.hist(output_sample2, bins=50, edgecolor='black', orientation='horizontal')
#ax3.hist(output_sample3/threshold, bins=50, edgecolor='black', orientation='horizontal')
#threshold = 0.211
#threshold = 0.2289

#ax3.axhline(y=1, color='red', linestyle='--', linewidth=2, label='1P Threshold')
ax3.axhline(y=threshold, color='red', linestyle='--', linewidth=2, label='1P Threshold')
ax3.set_title('Monte Carlo sample (size $n=10^7$)')
#ax3.set_xlabel('Frequency')
ax3.set_ylabel('')  # No label since it's shared with the first graph

# Adjust layout for better spacing
plt.tight_layout()

# Show the plot
plt.show()

import pdb;pdb.set_trace();

MCS = int(1e7)
distrib = ot.InverseNormal(16.0959, 22.3806) #2018 without outliers
distrib = ot.TruncatedDistribution(distrib, 0.0, 110.0)
UCS_sample = distrib.getSample(MCS)

with open("metamodel_SmallThicknessMP5.pkl", "rb") as f:
    metamodel = pickle.load(f)

output_sample1 = np.array(metamodel(UCS_sample))

#print(output_sample1)
#import pdb;pdb.set_trace();

with open("metamodel_OriginalDesign.pkl", "rb") as f:
    metamodel = pickle.load(f)

output_sample2 = np.array(metamodel(UCS_sample))

with open("metamodel_LargerThicknessMP5.pkl", "rb") as f:
    metamodel = pickle.load(f)
    
output_sample3 = np.array(metamodel(UCS_sample))

# Calculate the mean
#mean = np.mean(output_sample1)
# Print the results
print(f"Mean: {np.mean(output_sample1)}")
print(f"Mean: {np.mean(output_sample2)}")
print(f"Mean: {np.mean(output_sample3)}")

#import pdb;pdb.set_trace();

# Calculate the standard deviation
#std_dev = np.std(output_sample1)

# Calculate the coefficient of variation (CV = std_dev / mean)
#coefficient_of_variation = std_dev / mean

#np.std(output_sample1)/np.mean(output_sample1)

## Print the results
#print(f"Mean: {mean}")

print(f"Standard Deviation: {np.std(output_sample1)}")
print(f"Standard Deviation: {np.std(output_sample2)}")
print(f"Standard Deviation: {np.std(output_sample3)}")

print(f"Coefficient of Variation: {np.std(output_sample1)/np.mean(output_sample1)}")
print(f"Coefficient of Variation: {np.std(output_sample2)/np.mean(output_sample2)}")
print(f"Coefficient of Variation: {np.std(output_sample3)/np.mean(output_sample3)}")

import pdb;pdb.set_trace();

# Generate some example data
#data = np.random.normal(5, 1, 1000)  # Replace with your actual data

# Define a threshold

# Calculate the histogram data
counts1, bin_edges1 = np.histogram(Y1S, bins=30, density=True)
counts2, bin_edges2 = np.histogram(Y2S, bins=30, density=True)
counts3, bin_edges3 = np.histogram(Y3S, bins=30, density=True)

#print(len(Y1S))
#print(len(Y2S))
#print(len(Y3S))
#print(counts1)
#print(bin_edges1)
#print(Y1S)
#import pdb;pdb.set_trace();

# Calculate the failure probabilities (values below the threshold)
failure_probabilities1 = []
for i in range(len(bin_edges1) - 1):
    # Calculate the mid-point of each bin
    bin_midpoint1 = (bin_edges1[i] + bin_edges1[i+1]) / 2
    
    # If the bin midpoint is less than the threshold, add the bin's probability to the failure list
    if bin_midpoint1 < threshold:
        # Failure probability is proportional to the bin count
        failure_probabilities1.extend([counts1[i]])  # Extend with a proportionate number of occurrences

# Normalize the failure probabilities
total_count = sum(failure_probabilities1)  # Calculate the total sum of probabilities
failure_probabilities1 = [p / total_count for p in failure_probabilities1]  # Normalize the probabilities

# Calculate the failure probabilities (values below the threshold)
failure_probabilities2 = []
for i in range(len(bin_edges2) - 1):
    # Calculate the mid-point of each bin
    bin_midpoint2 = (bin_edges2[i] + bin_edges2[i+1]) / 2
    
    # If the bin midpoint is less than the threshold, add the bin's probability to the failure list
    if bin_midpoint2 < threshold:
        # Failure probability is proportional to the bin count
        failure_probabilities2.extend([counts2[i]])  # Extend with a proportionate number of occurrences

# Normalize the failure probabilities
total_count = sum(failure_probabilities2)  # Calculate the total sum of probabilities
failure_probabilities2 = [p / total_count for p in failure_probabilities2]  # Normalize the probabilities

# Calculate the failure probabilities (values below the threshold)
failure_probabilities3 = []
for i in range(len(bin_edges3) - 1):
    # Calculate the mid-point of each bin
    bin_midpoint3 = (bin_edges3[i] + bin_edges3[i+1]) / 2
    
    # If the bin midpoint is less than the threshold, add the bin's probability to the failure list
    if bin_midpoint3 < threshold:
        # Failure probability is proportional to the bin count
        failure_probabilities3.extend([counts3[i]])  # Extend with a proportionate number of occurrences

# Normalize the failure probabilities
total_count = sum(failure_probabilities3)  # Calculate the total sum of probabilities
failure_probabilities3 = [p / total_count for p in failure_probabilities3]  # Normalize the probabilities

# Create a box plot for failure probabilities
#plt.boxplot(failure_probabilities1)
#[failure_probabilities1, failure_probabilities2, failure_probabilities3]
#plt.boxplot([failure_probabilities1, failure_probabilities2, failure_probabilities3], labels=['Nominal MP diameter ', 'MP diameter +15%', 'MP diameter -15%'])
plt.boxplot([failure_probabilities1, failure_probabilities3], labels=['Nominal MP diameter', 'MP diameter -15%'])
#plt.boxplot([failure_probabilities1], labels=['Nominal MP diameter'])
#plt.axhline(y=0.2321, color='red', linestyle='--', linewidth=2, label='1P Threshold')

acceptable_threshold = 10**-4
plt.axhline(y=acceptable_threshold, color='red', linestyle='--', label=f'Threshold: $10^{{-4}}$')

# Add labels and title
plt.title('Box Plot of Failure Probabilities')
plt.ylabel('Probability')

# Show the plot
plt.show()


# List of positive-range distributions
distributions = [
    stats.norm,         # Normal distribution (can be used but has support over all real numbers)
    stats.expon,        # Exponential distribution
    stats.gamma,        # Gamma distribution
    stats.invgauss,     # Inverse Gaussian distribution
    stats.beta,         # Beta distribution
    stats.lognorm,      # Log-normal distribution
    stats.weibull_min,  # Weibull distribution
    stats.pareto,       # Pareto distribution
    stats.chi2,         # Chi-squared distribution
    stats.genextreme,   # Generalized extreme value (Frechet)
    stats.rayleigh,     # Rayleigh distribution
    stats.burr          # Burr distribution
]

best_fit = None
best_p_value = 0

for distribution in distributions:
    params = distribution.fit(np.array(F_pred2))
    ks_stat, p_value = stats.kstest(np.array(F_pred2), distribution.name, args=params)
    
    if p_value > best_p_value:
        best_fit = distribution
        best_p_value = p_value
        best_params = params

print(f"Best fitting distribution: {best_fit.name}, with p-value = {best_p_value}")

